<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "UserDatabase";

$conn = mysqli_connect($servername, $username, $password, $dbname);



?>
