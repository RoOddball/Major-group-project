<?php
/**
 * Created by PhpStorm.
 * User: denas
 * Date: 16/03/2019
 * Time: 17:23
 */
include "../src/User.php";
class UserTest
{

    public function testUser()
    {
        $user = new User();
    }


}