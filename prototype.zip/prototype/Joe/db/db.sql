drop database Joe;
create database Joe;
use Joe;

create table if not exists user(
    id int primary key auto_increment,
    username text,
    password text
);

truncate user;
insert into user values(1,'Joe','Joe12345');

select * from user;