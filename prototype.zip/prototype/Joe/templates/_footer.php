<!doctype html>
<html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>
        footer
    </title>
    <style>@import "/css/footer.css";</style>
</head>
<body>

<footer>
    Joe - 2019 All rights Reserved &copy;
</footer>

</body>
</html>
