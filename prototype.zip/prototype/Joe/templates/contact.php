<?php require_once __DIR__.'/../templates/_header.php';?>

    <body>
<div class="header">

    <h2>contact page</h2>

<?php require_once __DIR__.'/../templates/_footer.php';?>