<?php require_once __DIR__.'/../templates/_header.php';?>

    </head>
    <body>

    <div class="header">
        <h2>Review page</h2>
    </div>

    <h3 id="review"> only registered users can see this!!</h3>

<?php require_once __DIR__.'/../templates/_footer.php';?>