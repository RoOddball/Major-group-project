<?php require_once __DIR__.'/../templates/_header.php';?>
</head>
<body>

<div class="header">
    <h2>About</h2>
</div>


</body>
</html>

<?php require_once __DIR__.'/../templates/_footer.php';?>
