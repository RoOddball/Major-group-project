<h1>Message page</h1>

<p>
    <?= $message ?>
</p>
<hr>
<div class="middle">
    <section style="border-style: hidden">
        <p> Welcome to my website </p>
        <p> Thank you for making an account </p>
    </section>
</div>
<hr>

back to

<a href="index.php">
    home page
</a>