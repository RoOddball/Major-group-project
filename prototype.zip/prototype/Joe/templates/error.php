<h1>Error page</h1>


Sorry there were errors:

<p>
    <?= $message ?>
</p>

<hr>
back to

<a href="index.php">
    home page
</a>