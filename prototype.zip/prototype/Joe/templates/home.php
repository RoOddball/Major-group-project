<?php require_once __DIR__.'/../templates/_header.php';?>

<body>
<div class="header">
    <?php

    if($isLoggedIn):
        ?>
    <h3 id="review">you are now successfully logged in.
    click <a href="index.php?action=review">here</a> to check out the private</h3>

    <?php
    endif;
    ?>
<h2>Welcome to my website</h2>

<?php require_once __DIR__.'/../templates/_footer.php';?>