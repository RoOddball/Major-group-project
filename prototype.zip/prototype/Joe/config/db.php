<?php

define('DB_HOST', 'localhost:3306');
define('DB_USER', 'root');
define('DB_PASS', 'toor');
define('DB_NAME', 'Joe');
